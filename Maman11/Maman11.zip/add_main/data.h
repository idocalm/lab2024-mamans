#define BYTES 8
