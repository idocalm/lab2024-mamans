#define STRING_LENGTH 127

int suffix(char str[], char c);
